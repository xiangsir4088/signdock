SignDock - Portable (Green) Version
====================================

To run: double-click SignDock.exe in this folder.

The app lives in the system tray. Right-click the tray icon for:
  Open settings / Claim now (all) / Quit

Requirements:
  - Windows 10 2004+ or Windows 11
  - WebView2 Runtime (bundled into OS; older systems auto-install on first run)

No installation required. Safe to delete this folder to uninstall.

License: MIT (see LICENSE in source repo).
